class Maths :
	def addition(self,a,b) :
		print(a+b)
	def substraction(self,a,b) :
		print(a-b)
	def multiplication(self,a,b) :
		print(a*b)
	def division(self,a,b) :
		print(a/b)
